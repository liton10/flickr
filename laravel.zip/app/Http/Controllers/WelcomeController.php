<?php

namespace App\Http\Controllers;
use App\Article;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Request;

class WelcomeController extends Controller
{
    public function __construct(){
		
		}
		
	public function index() {
			
			
			
			return view('welcome');
			//return 'Hello';
		
		}
		
	 public function api($params) {
		 
		$params['api_key'] = 'f1f4fabdf832011b607b412ec86b5d25';
        $params['format'] = 'json';
        $params['nojsoncallback'] = 1;
       	$encoded_params = array();
        foreach ($params as $k => $v){
            $encoded_params[] = urlencode($k).'='.urlencode($v);
        }

        $url = "https://api.flickr.com/services/rest/?".implode('&', $encoded_params);
        $rsp = file_get_contents($url);
        $rsp_obj = json_decode($rsp, 1);
		
        return $rsp_obj;
    }
	
	public function searchImage() 
	{
		$tags = $_POST['imageName'];
		$params = array(
        'method'	=> 'flickr.photos.search',
        'tags' => $tags,
        'content_type' => 1, 
        'extras' => 'url_l,url_sq',
        'media' => 'photos',
        'per_page' => 10,
        'sort' => 'relevance'
    	);
		
		
		
        $encoded_params = array();
		
			foreach ($params as $k => $v){
				$encoded_params[] = urlencode($k).'='.urlencode($v);
			}

        //$photos = api($params); 
		$photos = $this->api($params);
		
		$result = array();
		
		
   		foreach($photos['photos']['photo'] as $p) {
			if(!isset($p['url_l'])) continue; // doesn't have big image, skip it
			
			$params = array(
				'method'	=> 'flickr.photos.getFavorites',
				'photo_id' => $p['id'],
			);
			$favs = $this->api($params);
			$favs = $favs['photo']['total']; // total count of favorites
			
			if($favs >= 5) {
					$params = array(
						'method'	=> 'flickr.photos.getInfo',
						'photo_id' => $p['id'],
					);
		
					$photo = $this->api($params);
					$data = array();
					$data['url_l'] = $p['url_l'];
					$data['url_sq'] = $p['url_sq'];
					$data['favorites'] = $favs;
					$data['owner'] = $photo['photo']['owner']['username'];
					$data['title'] = $photo['photo']['title']['_content'];
					$data['description'] = $photo['photo']['description']['_content'];
					$data['url'] = $photo['photo']['urls']['url'][0]['_content'];
		
					$result[] = $data;
			}
       

    	}
   
		//print_r($result);
		
		return view('welcome1',['data'=>$result]);
				
	}
		
	
}