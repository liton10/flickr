<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>

        <link href="//fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">

        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                color: #000000;
                display: table;
                font-weight: 100;
                
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 96px;
                margin-bottom: 40px;
            }

            .quote {
                font-size: 24px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="content">
            {!! Form::open() !!}
                
                   <div class="form-group">	
                   
                        {!! Form::label('imageName', 'Image Name:') !!}
                        {!! Form::text('imageName', null, ['class' => 'form-control']) !!}
                        {!! Form::submit('Search Image', ['class' => 'btn btn-primary form-control']) !!}
                        
                    </div>
                    
			{!! Form::close() !!}
            	
            @yield('content')
            	
            </div>
        </div>
    </body>
</html>
