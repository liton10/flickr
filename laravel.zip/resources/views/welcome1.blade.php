@extends('master')

@section('content')

                    <table width="80%">
                        <tr>
                            <td>Image</td>
                            <td>Title</td>
                            <td>Owner</td>
                            <td width="50%">Description</td>
                            <td>Favorites</td>
                            <td>Source</td>
                    
                        </tr>
                        <?php
                        
                        foreach($data as $r) {
                            ?>
                            <tr>
                                <td><a href="<?php echo $r['url_l']?>" target="_blank"><img src="<?php echo $r['url_sq'] ?>" /></td>
                                <td><?php echo $r['title']?></td>
                                <td><?php echo $r['owner']?></td>
                                <td><?php echo $r['description']?></td>
                                <td><?php echo $r['favorites']?></td>
                                <td><a href="<?php echo $r['url']?>" target="_blank">View in Flickr</td>
                            </tr>
                        
                            <?php
                        }
                        
                        ?>
                    </table>
@stop
